from flask import Blueprint, render_template, jsonify
import pandas as pd

app_routes = Blueprint('app_routes', __name__)

@app_routes.route('/')
def index():
    # Load recommendations
    recommendations = pd.read_json("data/results/recommendations.json", orient="index").to_dict()
    return render_template("index.html", recommendations=recommendations)
