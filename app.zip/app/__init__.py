from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = '5890ff0862f2dcae35cad9234b1bd0412d3f05bf35e8f5cc43c5c86959dd2307'

    from .routes import app_routes
    app.register_blueprint(app_routes)

    return app


