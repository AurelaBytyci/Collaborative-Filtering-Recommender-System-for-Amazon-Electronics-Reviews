from data_cleaner import clean_data
from recommender import train_recommender
import os

if __name__ == "__main__":
    # Paths
    raw_file_path = "../data/raw_data/Electronics_5.json"
    preprocessed_file_path = "../data/preprocessed_data/preprocessed_data.csv"
    output_json_path = "../data/results/recommendations.json"
    output_csv_path = "../data/results/top_5_recommendations.csv"

    print("Resolved raw path:", os.path.abspath(raw_file_path))

    # Step 1: Clean and save data
    clean_data(raw_file_path, preprocessed_file_path)

    # Step 2: Train the recommender system
    train_recommender(preprocessed_file_path, output_json_path, output_csv_path)

    print("Pipeline completed successfully!")
