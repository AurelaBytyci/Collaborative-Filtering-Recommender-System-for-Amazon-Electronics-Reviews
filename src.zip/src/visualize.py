import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def plot_rating_distribution(df):
    """Plot the distribution of ratings."""
    plt.figure(figsize=(8, 5))
    sns.countplot(x='overall', data=df, palette='viridis')
    plt.title('Rating Distribution')
    plt.xlabel('Ratings')
    plt.ylabel('Count')
    plt.show()

def plot_most_rated_items(df, n=10):
    """Plot the most rated items."""
    top_items = df['asin'].value_counts().head(n)
    plt.figure(figsize=(10, 6))
    top_items.plot(kind='bar', color='skyblue')
    plt.title('Top Rated Items')
    plt.xlabel('Item ID')
    plt.ylabel('Number of Ratings')
    plt.show()

if __name__ == "__main__":
    cleaned_data_path = "data/cleaned/cleaned_data.csv"
    df = pd.read_csv(cleaned_data_path)

    plot_rating_distribution(df)
    plot_most_rated_items(df)
