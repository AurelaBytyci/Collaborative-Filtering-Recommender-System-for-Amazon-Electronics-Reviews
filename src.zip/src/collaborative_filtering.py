import pandas as pd
from scipy.sparse.linalg import svds

def train_svd_model(ratings_matrix, k=50):
    """
    Train an SVD model on the user-item ratings matrix.

    Args:
    ratings_matrix (DataFrame): User-item matrix with ratings.
    k (int): Number of latent factors.

    Returns:
    DataFrame: Reconstructed matrix with predicted ratings.
    """
    # Normalize by subtracting mean
    user_ratings_mean = ratings_matrix.mean(axis=1).values.reshape(-1, 1)
    R_demeaned = ratings_matrix - user_ratings_mean

    # Decompose
    U, sigma, Vt = svds(R_demeaned.fillna(0), k=k)
    sigma = pd.DataFrame(sigma, index=range(k)).to_numpy()
    R_pred = pd.DataFrame(U.dot(sigma).dot(Vt), index=ratings_matrix.index, columns=ratings_matrix.columns)

    return R_pred + user_ratings_mean
