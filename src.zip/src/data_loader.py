import pandas as pd
import os

def load_electronics_data(filepath):
    """
    Load data from a CSV or JSON file.

    :param filepath: Path to the file.
    :return: Pandas DataFrame containing the data.
    """
    try:
        if filepath.endswith('.csv'):
            data = pd.read_csv(filepath)
        elif filepath.endswith('.json'):
            chunksize = 10000  # Load only first 10,000 lines
            data = pd.read_json(filepath, lines=True, chunksize=chunksize)
            data = next(data)  # Get only the first chunk
        else:
            raise ValueError("Unsupported file format. Use .csv or .json.")
    except Exception as e:
        raise RuntimeError(f"Error loading data: {e}")

    return data


if __name__ == "__main__":
    # Dynamically resolve the raw data path
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    raw_data_path = os.path.join(project_root, "data/raw_data/Electronics_5.json")

    # Debugging path resolution
    print(f"Resolved path to raw data: {raw_data_path}")
    print(f"File exists: {os.path.exists(raw_data_path)}")

    # Load the data
    print("Loading data...")
    electronics_data = load_electronics_data(raw_data_path)

    # Print the first few rows
    print(electronics_data.head())
