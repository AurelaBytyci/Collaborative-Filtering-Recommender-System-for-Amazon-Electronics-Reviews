import pandas as pd
import os

def clean_data(raw_file_path, cleaned_file_path):
    """
    Reads raw JSON data, cleans it, and saves it to a CSV file.
    """
    print(f"Reading raw data from: {os.path.abspath(raw_file_path)}")

    # Check if the raw file exists
    if not os.path.exists(raw_file_path):
        raise FileNotFoundError(f"Raw data file not found: {raw_file_path}")

    try:
        # Load raw JSON data
        # Load only the first N lines for faster processing
        max_lines = 10000
        data = pd.read_json(raw_file_path, lines=True, chunksize=max_lines)
        data = next(data)  # Load just the first chunk


        print("Cleaning data...")
        # Keep only the necessary columns
        if {'reviewerID', 'asin', 'overall'}.issubset(data.columns):
            cleaned_data = data[['reviewerID', 'asin', 'overall']].dropna()

            # Rename columns
            cleaned_data.columns = ['user_id', 'item_id', 'rating']

            # Save cleaned data to CSV
            os.makedirs(os.path.dirname(cleaned_file_path), exist_ok=True)
            cleaned_data.to_csv(cleaned_file_path, index=False)
            print(f"Cleaned data saved to: {os.path.abspath(cleaned_file_path)}")
        else:
            print("Required columns not found in the raw data.")
            print(f"Available columns: {list(data.columns)}")
    except Exception as e:
        print(f"Error processing raw data: {e}")
        raise

if __name__ == "__main__":
    # Define file paths
    raw_file_path = '../data/raw_data/Electronics_5.json'
    cleaned_file_path = "data/preprocessed_data/preprocessed_data.csv"

    # Clean and save the data
    clean_data(raw_file_path, cleaned_file_path)
    print("Data cleaning completed successfully!")
