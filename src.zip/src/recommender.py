import os

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import svds


def train_recommender(data_path, output_json_path, output_csv_path):
    """
    Trains the SVD recommender system and saves top recommendations as JSON and optionally CSV.
    """
    print(f"Training recommender system using data: {data_path}")

    # Check if the file exists
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"Input file not found: {data_path}")

    # Load preprocessed data
    df = pd.read_csv(data_path)

    # Filter top users and items
    top_users = df['user_id'].value_counts().head(1000).index
    top_items = df['item_id'].value_counts().head(1000).index
    df = df[df['user_id'].isin(top_users) & df['item_id'].isin(top_items)]

    # Create sparse matrix
    user_ids = df['user_id'].astype('category').cat.codes
    item_ids = df['item_id'].astype('category').cat.codes
    ratings = df['rating']

    sparse_matrix = csr_matrix((ratings, (user_ids, item_ids)), dtype=np.float32)

    # Normalize and apply SVD
    user_ratings_mean = np.array(sparse_matrix.mean(axis=1)).flatten()
    matrix_demeaned = sparse_matrix - user_ratings_mean.reshape(-1, 1)

    U, sigma, Vt = svds(matrix_demeaned, k=20)
    sigma = np.diag(sigma)

    # Predicted ratings
    predicted_ratings = np.dot(np.dot(U, sigma), Vt) + user_ratings_mean.reshape(-1, 1)
    predictions_df = pd.DataFrame(predicted_ratings)

    # Top-5 recommendations
    top_5_recommendations = predictions_df.apply(lambda row: row.nlargest(5).index.tolist(), axis=1)
    print("Saving recommendations...")

    # Save as JSON
    os.makedirs(os.path.dirname(output_json_path), exist_ok=True)
    top_5_recommendations.to_json(output_json_path, orient="index")
    print(f"Recommendations saved to {output_json_path}")

    # Save as CSV
    os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
    top_5_recommendations.to_csv(output_csv_path, index=False)
    print(f"Top-5 recommendations saved to {output_csv_path}")


if __name__ == "__main__":
    # Paths
    preprocessed_data_path = "data/preprocessed_data/preprocessed_data.csv"
    output_json_path = "data/results/recommendations.json"
    output_csv_path = "data/results/top_5_recommendations.csv"

    # Run the recommender
    train_recommender(preprocessed_data_path, output_json_path, output_csv_path)
