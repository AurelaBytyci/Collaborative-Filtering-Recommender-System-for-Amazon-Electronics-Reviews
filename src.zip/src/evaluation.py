import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.decomposition import TruncatedSVD

def evaluate_model(input_path):
    print("Loading preprocessed data...")
    data = pd.read_csv(input_path)

    # Filter for users/items with at least 3 ratings
    print("Filtering data...")
    user_counts = data['user_id'].value_counts()
    item_counts = data['item_id'].value_counts()
    data = data[data['user_id'].isin(user_counts[user_counts >= 3].index)]
    data = data[data['item_id'].isin(item_counts[item_counts >= 3].index)]
    print(f"Remaining data rows after filtering: {len(data)}")

    # Create user-item rating matrix (with NaNs for unrated)
    print("Creating user-item matrix...")
    df_matrix = data.pivot_table(index='user_id', columns='item_id', values='rating')
    print(f"Matrix shape: {df_matrix.shape}")

    # Mean center (ignoring NaNs)
    print("Normalizing ratings...")
    mean_user_ratings = df_matrix.mean(axis=1)
    normalized_matrix = df_matrix.sub(mean_user_ratings, axis=0).fillna(0)

    # Apply SVD
    print("Applying Truncated SVD...")
    svd = TruncatedSVD(n_components=20, random_state=42)
    U = svd.fit_transform(normalized_matrix)
    sigma = svd.singular_values_
    Vt = svd.components_

    # Reconstruct the matrix
    print("Reconstructing the ratings matrix...")
    reconstructed_matrix = np.dot(np.dot(U, np.diag(sigma)), Vt)

    # Add mean ratings back
    mean_user_ratings_array = mean_user_ratings.values.reshape(-1, 1)
    reconstructed_matrix += mean_user_ratings_array

    # Convert original and predicted back to arrays for RMSE
    original = df_matrix.to_numpy()
    mask = ~np.isnan(original)
    predicted = reconstructed_matrix

    print(f"Reconstructed matrix min: {predicted.min():.2f}, max: {predicted.max():.2f}")

    print("Calculating RMSE...")
    rmse = np.sqrt(mean_squared_error(original[mask], predicted[mask]))
    print(f"Model RMSE: {rmse:.2f}")


if __name__ == "__main__":
    input_path = "data/preprocessed_data/preprocessed_data.csv"
    evaluate_model(input_path)
